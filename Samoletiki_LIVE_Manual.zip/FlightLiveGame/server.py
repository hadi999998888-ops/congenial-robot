from __future__ import annotations

import asyncio
import os
import time
from collections import deque
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent
EVENTS: deque[dict[str, Any]] = deque(maxlen=1200)
NEXT_EVENT_ID = 0
JOIN_EVENT_COUNT = 0
TIKTOK_CLIENT: Any = None
TIKTOK_TASK: Any = None
TIKTOK_USERNAME = ""
TIKTOK_CONNECTING = False
TIKTOK_CONNECTED = False
LAST_ERROR = ""
JOIN_MODE = "any"
JOIN_COMMAND = "!лети"

app = FastAPI(title="Самолётики LIVE", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)
app.mount("/assets", StaticFiles(directory=BASE_DIR / "assets"), name="assets")


class ConnectRequest(BaseModel):
    username: str = Field(min_length=1, max_length=40)
    mode: str = "any"
    command: str = Field(default="!лети", max_length=24)


class DemoRequest(BaseModel):
    name: str = Field(default="Гость", min_length=1, max_length=40)


class ManualRosterRequest(BaseModel):
    names: list[str] = Field(min_length=1, max_length=30)
    armored: bool = True


def emit(event_type: str, **payload: Any) -> dict[str, Any]:
    global NEXT_EVENT_ID, JOIN_EVENT_COUNT
    NEXT_EVENT_ID += 1
    event = {"id": NEXT_EVENT_ID, "type": event_type, "created_at": time.time(), **payload}
    EVENTS.append(event)
    if event_type == "join":
        JOIN_EVENT_COUNT += 1
    return event


@app.get("/")
async def index() -> FileResponse:
    return FileResponse(BASE_DIR / "index.html")


@app.get("/control")
async def control() -> FileResponse:
    return FileResponse(BASE_DIR / "control.html")


@app.get("/manifest.webmanifest")
async def manifest() -> FileResponse:
    return FileResponse(BASE_DIR / "manifest.webmanifest", media_type="application/manifest+json")


@app.get("/api/status")
async def status() -> dict[str, Any]:
    return {
        "connected": TIKTOK_CONNECTED,
        "connecting": TIKTOK_CONNECTING,
        "username": TIKTOK_USERNAME,
        "last_error": LAST_ERROR,
        "event_count": JOIN_EVENT_COUNT,
        "last_event_id": NEXT_EVENT_ID,
        "join_mode": JOIN_MODE,
    }


@app.get("/api/events")
async def get_events(after: int = 0) -> dict[str, Any]:
    selected = [event for event in EVENTS if event["id"] > after]
    return {
        "events": selected,
        "connected": TIKTOK_CONNECTED,
        "last_event_id": NEXT_EVENT_ID,
    }


@app.post("/api/demo")
async def add_demo(payload: DemoRequest) -> dict[str, Any]:
    name = payload.name.strip()[:22] or "Гость"
    event = emit("join", name=name, unique_id=f"demo_{name}", source="demo")
    return {"ok": True, "event": event}


@app.post("/api/manual-roster")
async def manual_roster(payload: ManualRosterRequest) -> dict[str, Any]:
    names: list[str] = []
    seen: set[str] = set()
    for raw in payload.names:
        name = str(raw).replace("<", "").replace(">", "").strip()[:22]
        key = name.casefold()
        if name and key not in seen:
            seen.add(key)
            names.append(name)
    if not names:
        raise HTTPException(status_code=400, detail="Впиши хотя бы один ник")
    emit("manual_roster", players=[{"name": name, "armored": payload.armored} for name in names])
    return {"ok": True, "count": len(names), "armored": payload.armored}


@app.post("/api/start")
async def start_manual() -> dict[str, bool]:
    emit("start")
    return {"ok": True}


@app.post("/api/reset")
async def reset() -> dict[str, bool]:
    emit("reset")
    return {"ok": True}


async def stop_tiktok_client() -> None:
    global TIKTOK_CLIENT, TIKTOK_TASK, TIKTOK_CONNECTED, TIKTOK_CONNECTING
    if TIKTOK_CLIENT is not None:
        try:
            await TIKTOK_CLIENT.disconnect()
        except Exception:
            pass
    if TIKTOK_TASK is not None and not TIKTOK_TASK.done():
        TIKTOK_TASK.cancel()
        try:
            await TIKTOK_TASK
        except (asyncio.CancelledError, Exception):
            pass
    TIKTOK_CLIENT = None
    TIKTOK_TASK = None
    TIKTOK_CONNECTED = False
    TIKTOK_CONNECTING = False


@app.post("/api/disconnect")
async def disconnect() -> dict[str, Any]:
    await stop_tiktok_client()
    emit("connection", connected=False, username=TIKTOK_USERNAME)
    return {"ok": True, "message": "Подключение остановлено"}


@app.post("/api/connect")
async def connect(payload: ConnectRequest) -> dict[str, Any]:
    global TIKTOK_CLIENT, TIKTOK_TASK, TIKTOK_USERNAME
    global TIKTOK_CONNECTING, TIKTOK_CONNECTED, LAST_ERROR, JOIN_MODE, JOIN_COMMAND

    username = payload.username.strip().lstrip("@").strip()
    if not username or any(ch.isspace() for ch in username):
        raise HTTPException(status_code=400, detail="Проверь ник TikTok")

    await stop_tiktok_client()
    TIKTOK_USERNAME = username
    JOIN_MODE = "command" if payload.mode == "command" else "any"
    JOIN_COMMAND = payload.command.strip() or "!лети"
    LAST_ERROR = ""
    TIKTOK_CONNECTING = True
    TIKTOK_CONNECTED = False

    try:
        # TikTokLive is intentionally optional: the local demo still works without it.
        from TikTokLive import TikTokLiveClient
        from TikTokLive.events import CommentEvent, ConnectEvent, DisconnectEvent, FollowEvent

        client = TikTokLiveClient(unique_id=username)
        TIKTOK_CLIENT = client

        @client.on(ConnectEvent)
        async def on_connect(event: Any) -> None:
            global TIKTOK_CONNECTED, TIKTOK_CONNECTING, LAST_ERROR
            TIKTOK_CONNECTED = True
            TIKTOK_CONNECTING = False
            LAST_ERROR = ""
            emit("connection", connected=True, username=username)
            print(f"[TikTok LIVE] Connected to @{username}")

        @client.on(DisconnectEvent)
        async def on_disconnect(event: Any) -> None:
            global TIKTOK_CONNECTED
            TIKTOK_CONNECTED = False
            emit("connection", connected=False, username=username)
            print(f"[TikTok LIVE] Disconnected from @{username}")

        @client.on(FollowEvent)
        async def on_follow(event: Any) -> None:
            user = getattr(event, "user", None)
            if user is None:
                return
            unique_id = str(getattr(user, "unique_id", "") or "").strip()
            nickname = str(getattr(user, "nickname", "") or unique_id or "Гость").strip()
            if not nickname:
                nickname = "Гость"
            emit("join", name=nickname[:22], unique_id=unique_id or nickname, source="follow")
            print(f"[follow] {nickname}")

        @client.on(CommentEvent)
        async def on_comment(event: Any) -> None:
            comment = str(getattr(event, "comment", "") or "")
            if JOIN_MODE == "command" and comment.strip().casefold() != JOIN_COMMAND.casefold():
                return
            user = getattr(event, "user", None)
            if user is None:
                return
            unique_id = str(getattr(user, "unique_id", "") or "").strip()
            nickname = str(getattr(user, "nickname", "") or unique_id or "Гость").strip()
            if not nickname:
                nickname = "Гость"
            emit(
                "join",
                name=nickname[:22],
                unique_id=unique_id or nickname,
                source="chat",
                comment=comment[:120],
            )
            print(f"[chat] {nickname}: {comment[:80]}")

        # start() is non-blocking and returns the client's asyncio task.
        client_loop_task = await client.start()

        async def monitor_client() -> None:
            global TIKTOK_CONNECTED, TIKTOK_CONNECTING, LAST_ERROR
            try:
                await client_loop_task
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                TIKTOK_CONNECTED = False
                TIKTOK_CONNECTING = False
                LAST_ERROR = f"Связь с LIVE прервалась: {type(exc).__name__}: {exc}"
                print(f"[TikTok LIVE] {LAST_ERROR}")

        TIKTOK_TASK = asyncio.create_task(monitor_client())
        return {
            "ok": True,
            "message": f"Подключаемся к @{username}…",
            "mode": JOIN_MODE,
        }
    except ImportError:
        TIKTOK_CONNECTING = False
        LAST_ERROR = "Библиотека TikTokLive не установлена. Выполни: pip install -r requirements.txt"
        raise HTTPException(status_code=503, detail=LAST_ERROR)
    except Exception as exc:
        TIKTOK_CONNECTING = False
        TIKTOK_CONNECTED = False
        LAST_ERROR = f"Не удалось подключиться: {type(exc).__name__}: {exc}"
        raise HTTPException(status_code=502, detail=LAST_ERROR)


@app.on_event("shutdown")
async def shutdown_event() -> None:
    await stop_tiktok_client()


if __name__ == "__main__":
    import uvicorn

    host = os.environ.get("FLIGHT_HOST", "127.0.0.1")
    port = int(os.environ.get("FLIGHT_PORT", "8787"))
    print("\nСамолётики LIVE запущены")
    print(f"Игра:    http://{host}:{port}/")
    print(f"Панель:  http://{host}:{port}/control\n")
    uvicorn.run(app, host=host, port=port, reload=False)
