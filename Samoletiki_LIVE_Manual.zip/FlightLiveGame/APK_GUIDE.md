# APK — краткая инструкция

В проекте есть GitHub Actions сборка Android debug APK. Android SDK не включён в архив: workflow использует Android SDK на GitHub Actions.

1. Загрузи проект в свой GitHub-репозиторий (все файлы и папки, включая `.github`).
2. Включи Actions, если GitHub попросит.
3. Открой Actions → Build Android APK → Run workflow.
4. Скачай artifact `samoletiki-live-debug-apk` из готового запуска.

APK содержит экран игры и умеет работать в тестовом/локальном режиме. Чтобы получать реальные комментарии TikTok, Python-сервер из проекта должен быть запущен на компьютере или сервере. Для телефона укажи доступный адрес сервера в панели управления.
