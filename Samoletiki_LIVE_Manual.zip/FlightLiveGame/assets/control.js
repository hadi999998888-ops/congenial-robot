(() => {
  const $ = (id) => document.getElementById(id);
  const API_BASE = (localStorage.getItem('flightApiBase') || '').trim().replace(/\/$/, '');
  const statusText = $('statusText');
  const statusLine = statusText.parentElement;
  const toastEl = $('toast');
  let connected = false;
  let toastTimer;

  const toast = (message) => {
    toastEl.textContent = message;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => toastEl.classList.remove('show'), 2600);
  };

  async function api(path, options = {}) {
    const response = await fetch(`${API_BASE}${path}`, {
      headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
      ...options,
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.detail || data.error || `Ошибка сервера: ${response.status}`);
    return data;
  }

  function setStatus(text, mode = '') {
    statusText.textContent = text;
    statusLine.classList.toggle('ok', mode === 'ok');
    statusLine.classList.toggle('bad', mode === 'bad');
    connected = mode === 'ok';
  }

  $('anyComment').addEventListener('change', () => {
    $('commandRow').hidden = $('anyComment').checked;
  });

  $('disconnectBtn').addEventListener('click', async () => {
    try {
      const data = await api('/api/disconnect', { method: 'POST', body: '{}' });
      setStatus(data.message || 'Отключено');
      toast('Подключение остановлено');
    } catch (error) { toast(error.message); }
  });

  $('connectBtn').addEventListener('click', async () => {
    const username = $('tiktokUser').value.trim().replace(/^@/, '');
    if (!username) return toast('Введи ник TikTok без ссылки');
    $('connectBtn').disabled = true;
    setStatus('Подключаемся к LIVE…');
    try {
      const data = await api('/api/connect', { method: 'POST', body: JSON.stringify({
        username,
        mode: $('anyComment').checked ? 'any' : 'command',
        command: $('joinCommand').value.trim() || '!лети',
      }) });
      $('tiktokUser').value = username;
      setStatus(data.message || `Подключено к @${username}`, 'ok');
      toast('Запрос на подключение отправлен');
    } catch (error) {
      setStatus(error.message, 'bad'); toast(error.message);
    } finally { $('connectBtn').disabled = false; }
  });


  $('loadManual').addEventListener('click', async () => {
    const names = $('manualNames').value.split(/\r?\n/).map(v => v.trim()).filter(Boolean);
    if (!names.length) return toast('Сначала впиши хотя бы один ник');
    if (names.length > 30) return toast('Максимум 30 участников за раз');
    try {
      const data = await api('/api/manual-roster', { method: 'POST', body: JSON.stringify({ names, armored: $('manualArmored').checked }) });
      toast(`Подготовлено участников: ${data.count}. Теперь нажми «Запустить заезд»`);
    } catch (e) { toast(e.message); }
  });

  $('launchManual').addEventListener('click', async () => {
    try { await api('/api/start', { method: 'POST', body: '{}' }); toast('Заезд запускается! ✈'); }
    catch (e) { toast(e.message); }
  });

  $('addDemo').addEventListener('click', async () => {
    const name = $('demoName').value.trim() || 'Гость';
    try { await api('/api/demo', { method: 'POST', body: JSON.stringify({ name }) }); toast(`${name} добавлен в игру`); }
    catch (e) { toast(`Сервер недоступен: ${e.message}`); }
  });

  $('addBatch').addEventListener('click', async () => {
    const names = ['Макс', 'Лиза', 'Аня', 'Dimon_228', 'Тимур'];
    try {
      for (const name of names) await api('/api/demo', { method: 'POST', body: JSON.stringify({ name }) });
      toast('Добавлено 5 тестовых игроков');
    } catch (e) { toast(`Сервер недоступен: ${e.message}`); }
  });

  $('resetGame').addEventListener('click', async () => {
    try { await api('/api/reset', { method: 'POST', body: '{}' }); toast('Раунд сброшен'); }
    catch (e) { toast(`Сервер недоступен: ${e.message}`); }
  });

  $('saveApi').addEventListener('click', () => {
    const value = $('apiBase').value.trim().replace(/\/$/, '');
    if (value && !/^https?:\/\//i.test(value)) return toast('Адрес должен начинаться с http:// или https://');
    localStorage.setItem('flightApiBase', value);
    toast('Адрес сохранён. Перезагрузи страницу игры.');
  });

  async function refresh() {
    try {
      const data = await api('/api/status');
      if (data.connected) setStatus(`Подключено к @${data.username}`, 'ok');
      else if (data.connecting) setStatus(`Подключаемся к @${data.username}…`);
      else setStatus(data.last_error || 'Сервер запущен, TikTok не подключён');
      $('serverStatus').textContent = 'ONLINE';
      $('playersCount').textContent = data.event_count ?? '—';
      $('roundStatus').textContent = data.connected ? 'Чат активен' : 'Ожидание';
    } catch {
      setStatus('Сервер не найден. Запусти start_windows.bat или start_termux.sh.', 'bad');
      $('serverStatus').textContent = 'OFFLINE';
    }
  }
  $('apiBase').value = API_BASE;
  refresh(); setInterval(refresh, 2500);
})();
