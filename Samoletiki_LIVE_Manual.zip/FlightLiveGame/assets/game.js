(() => {
  'use strict';

  const MAX_DISTANCE = 10000;
  const stage = document.getElementById('stage');
  const world = document.getElementById('flightWorld');
  const layer = document.getElementById('planesLayer');
  const leaderRows = document.getElementById('leaderRows');
  const waitingState = document.getElementById('waitingState');
  const phaseTitle = document.getElementById('phaseTitle');
  const phaseText = document.getElementById('phaseText');
  const finishBanner = document.getElementById('finishBanner');
  const finishWinner = document.getElementById('finishWinner');
  const finishTime = document.getElementById('finishTime');
  const winnerName = document.getElementById('winnerName');
  const winnerMeta = document.getElementById('winnerMeta');
  const meterFill = document.getElementById('meterFill');
  const meterDot = document.getElementById('meterDot');
  const countdownEl = document.getElementById('roundCountdown');
  const connectionChip = document.getElementById('connectionChip');
  const connectionLabel = document.getElementById('connectionLabel');
  const confettiLayer = document.getElementById('confettiLayer');

  const API_BASE = (localStorage.getItem('flightApiBase') || '').trim().replace(/\/$/, '');
  const PALETTE = ['#f04d62','#36d8c4','#ffd05a','#42e28a','#fb9b43','#a58cff','#ff76b6','#80d6ff'];
  const THEMES = ['sea','day','night'];
  const state = {
    phase: 'waiting', players: [], queued: [], winner: null,
    countdownAt: 0, finishedAt: 0, roundStartedAt: 0,
    themeIndex: 0, apiConnected: false, apiAvailable: false,
    lastEventId: 0, apiCursorInitialized: false, lastFrame: 0, roundNumber: 1,
  };

  const cleanName = (value) => String(value || 'Гость').replace(/[<>\u0000-\u001f]/g, '').trim().slice(0, 22) || 'Гость';
  const safeKey = (value) => String(value || '').toLowerCase().replace(/[^\p{L}\p{N}_-]/gu, '').slice(0, 44);
  const planeSvg = (color) => `
    <svg class="plane-svg" viewBox="0 0 120 190" aria-hidden="true">
      <path d="M58 174 L48 148 L72 148 Z" fill="#ffcf58" opacity=".9"/><path d="M58 181 L53 162 L63 162 Z" fill="#ff8c39"/>
      <path d="M52 38 Q60 3 68 38 L77 142 Q60 157 43 142 Z" fill="#fff5d2" stroke="#927548" stroke-width="2"/>
      <path d="M48 83 L7 109 Q3 112 8 119 L45 125 L53 111 Z" fill="${color}" stroke="#ffe5a0" stroke-width="2"/>
      <path d="M72 83 L113 109 Q117 112 112 119 L75 125 L67 111 Z" fill="${color}" stroke="#ffe5a0" stroke-width="2"/>
      <path d="M48 136 L28 149 L31 158 L53 153 Z M72 136 L92 149 L89 158 L67 153 Z" fill="${color}" stroke="#ffe5a0" stroke-width="2"/>
      <path d="M55 50 Q60 37 65 50 L68 76 L52 76 Z" fill="#203d6b"/><ellipse cx="60" cy="61" rx="4" ry="8" fill="#a9efff"/>
      <path d="M50 97 L70 97 L73 105 L47 105 Z" fill="#d2ae59"/><path d="M50 130 L70 130 L68 141 L52 141 Z" fill="#c0ae83"/>
    </svg>`;

  function makePlayer(name, id = '', source = 'chat', armored = true) {
    const display = cleanName(name);
    const key = safeKey(id || display) || `guest-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    return {
      id: key, name: display, distance: 0, speed: 185 + Math.random() * 70,
      color: PALETTE[state.players.length % PALETTE.length],
      lane: state.players.length % 6, armored: !!armored, shield: armored ? 1 : 0, hitAt: 3500 + Math.random() * 4300,
      source, time: 0, element: null, done: false,
    };
  }

  function addParticipant(name, id = '', source = 'chat', armored = true) {
    const display = cleanName(name);
    const key = safeKey(id || display);
    const exists = [...state.players, ...state.queued].some(p => p.id === key || p.name.toLowerCase() === display.toLowerCase());
    if (exists) return false;
    if (state.phase === 'finished') {
      const player = makePlayer(display, id, source, armored);
      player.color = PALETTE[state.queued.length % PALETTE.length];
      state.queued.push(player);
      renderBoard();
      return true;
    }
    const player = makePlayer(display, id, source, armored);
    player.color = PALETTE[state.players.length % PALETTE.length];
    state.players.push(player);
    renderBoard();
    renderPlanes();
    if (state.phase === 'waiting') {
      state.phase = 'countdown';
      state.countdownAt = performance.now() + 5000;
      world.classList.remove('racing', 'finished');
      phaseTitle.textContent = 'САМОЛЁТИКИ ГОТОВЫ';
      phaseText.textContent = 'Взлёт через несколько секунд…';
      waitingState.style.opacity = '1';
    }
    return true;
  }

  function beginRound(now) {
    state.phase = 'racing';
    state.roundStartedAt = now;
    state.players.forEach((p, index) => {
      p.distance = 0; p.time = 0; p.done = false;
      p.lane = index % 6;
      p.speed = 185 + Math.random() * 70;
      p.shield = p.armored ? 1 : 0;
      p.hitAt = 2500 + Math.random() * 5700;
    });
    world.classList.add('racing');
    world.classList.remove('finished');
    finishBanner.hidden = true;
    countdownEl.hidden = true;
    renderPlanes();
    phaseTitle.textContent = 'ПОЛЕТЕЛИ!';
    phaseText.textContent = 'Кто первым наберёт 10 000 км?';
  }

  function finishRound(player, now) {
    if (state.phase !== 'racing') return;
    player.distance = MAX_DISTANCE;
    player.done = true;
    player.time = Math.max(1, (now - state.roundStartedAt) / 1000);
    state.phase = 'finished';
    state.finishedAt = now;
    state.winner = player;
    world.classList.remove('racing');
    world.classList.add('finished');
    finishBanner.hidden = false;
    finishWinner.textContent = player.name;
    finishTime.textContent = `долетел за ${Math.round(player.time)} сек`;
    winnerName.textContent = player.name;
    winnerMeta.textContent = `10 000 км · ${Math.round(player.time)} с`;
    phaseTitle.textContent = 'ПОБЕДИТЕЛЬ';
    phaseText.textContent = `${player.name} первым добрался до финиша!`;
    createConfetti();
    renderBoard();
    renderPlanes();
  }

  function startNextRound(now) {
    state.players = state.queued.splice(0);
    state.players.forEach((p, i) => { p.distance = 0; p.done = false; p.lane = i % 6; p.color = PALETTE[i % PALETTE.length]; });
    state.winner = null;
    state.phase = 'waiting';
    state.roundNumber += 1;
    state.themeIndex = (state.themeIndex + 1) % THEMES.length;
    stage.dataset.theme = THEMES[state.themeIndex];
    world.classList.remove('racing', 'finished');
    finishBanner.hidden = true;
    confettiLayer.innerHTML = '';
    if (state.players.length) {
      state.phase = 'countdown';
      state.countdownAt = now + 4000;
    }
    renderBoard(); renderPlanes(); updateStatusText();
  }

  function renderBoard() {
    const ranking = [...state.players].sort((a, b) => b.distance - a.distance).slice(0, 5);
    if (!ranking.length) {
      leaderRows.innerHTML = '<div class="empty-row">Пока нет участников</div>';
      return;
    }
    leaderRows.innerHTML = ranking.map((p, i) => {
      const displayDistance = Math.floor(p.distance).toLocaleString('ru-RU').replace(/\u00a0/g, ' ');
      return `<div class="leader-row"><span class="leader-left"><span style="color:${p.color}">●</span> ${i + 1}. ${p.shield ? '🌹 ' : ''}${escapeHtml(p.name)}</span><span class="leader-score">${displayDistance}</span></div>`;
    }).join('');
  }

  function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

  function renderPlanes() {
    const shown = state.players;
    const currentIds = new Set(shown.map(p => p.id));
    [...layer.children].forEach(el => { if (!currentIds.has(el.dataset.id)) el.remove(); });
    shown.forEach((p, index) => {
      let el = p.element || layer.querySelector(`[data-id="${CSS.escape(p.id)}"]`);
      if (!el) {
        el = document.createElement('div');
        el.className = 'flyer'; el.dataset.id = p.id;
        el.style.setProperty('--plane-color', p.color);
        el.innerHTML = `<div class="name-tag"></div><div class="shield-ring"></div>${planeSvg(p.color)}<div class="distance-tag"></div>`;
        layer.appendChild(el); p.element = el;
      }
      const lanes = Math.min(6, Math.max(1, shown.length));
      const lane = p.lane % 6;
      const left = shown.length === 1 ? 42 : 4 + lane * (88 / Math.max(1, lanes - 1));
      const percent = Math.min(1, p.distance / MAX_DISTANCE);
      const bottom = 8 + percent * 67;
      el.style.left = `${Math.max(1, Math.min(83, left))}%`;
      el.style.bottom = `${bottom}%`;
      el.style.setProperty('--plane-color', p.color);
      el.classList.toggle('shield-used', !p.shield);
      el.querySelector('.name-tag').textContent = `${p.shield ? '🌹 ' : ''}${p.name}`;
      el.querySelector('.distance-tag').textContent = state.phase === 'racing' ? `${Math.floor(p.distance).toLocaleString('ru-RU')} км` : '';
      el.style.opacity = '1';
      if (state.players.length > 7) el.style.transform = `scale(${Math.max(.72, 1 - (state.players.length - 7) * .025)})`;
      else el.style.transform = '';
    });
  }

  function updateStatusText() {
    if (state.phase === 'waiting') {
      phaseTitle.textContent = 'ЖДЁМ УЧАСТНИКОВ';
      phaseText.textContent = 'Напиши в чат — и твой самолётик взлетит!';
      waitingState.style.opacity = '1';
      countdownEl.hidden = true;
    }
  }

  function createConfetti() {
    confettiLayer.innerHTML = '';
    const colors = ['#ffcb58','#ff5f78','#40d6bd','#77e58f','#a98cff','#fff'];
    for (let i = 0; i < 66; i++) {
      const item = document.createElement('i');
      item.className = 'confetti';
      item.style.left = `${Math.random() * 100}%`;
      item.style.background = colors[i % colors.length];
      item.style.animationDelay = `${Math.random() * 1.5}s`;
      item.style.transform = `rotate(${Math.random() * 90}deg)`;
      confettiLayer.appendChild(item);
    }
  }

  function updateMeter() {
    const leader = Math.max(0, ...state.players.map(p => p.distance));
    const percent = Math.min(100, leader / MAX_DISTANCE * 100);
    meterFill.style.height = `${percent}%`;
    meterDot.style.bottom = `${percent}%`;
  }

  function tick(now) {
    if (!state.lastFrame) state.lastFrame = now;
    const dt = Math.min(.06, (now - state.lastFrame) / 1000);
    state.lastFrame = now;

    if (state.phase === 'countdown') {
      const left = state.countdownAt - now;
      countdownEl.hidden = false;
      countdownEl.textContent = left > 1000 ? `✈️ ВЗЛЁТ ЧЕРЕЗ ${Math.ceil(left / 1000)}` : '✈️ ПОЕХАЛИ!';
      if (left <= 0) beginRound(now);
    } else if (state.phase === 'racing') {
      let finisher = null;
      state.players.forEach(p => {
        if (p.done) return;
        p.time += dt;
        const wobble = 0.88 + Math.sin(now / 420 + p.lane) * .05 + Math.random() * .12;
        let speed = p.speed * wobble;
        if (p.shield && p.distance > p.hitAt) {
          p.shield = 0;
          p.hitAt = Infinity;
          speed *= .72;
        }
        p.distance = Math.min(MAX_DISTANCE, p.distance + speed * dt);
        if (p.distance >= MAX_DISTANCE && !finisher) finisher = p;
      });
      if (finisher) finishRound(finisher, now);
    } else if (state.phase === 'finished') {
      const left = 13000 - (now - state.finishedAt);
      countdownEl.hidden = false;
      countdownEl.textContent = `СЛЕДУЮЩИЙ ЗАЕЗД ЧЕРЕЗ ${Math.max(0, Math.ceil(left / 1000))}`;
      if (left <= 0) startNextRound(now);
    }

    renderPlanes();
    renderBoard();
    updateMeter();
    requestAnimationFrame(tick);
  }

  async function apiStatus() {
    try {
      const response = await fetch(`${API_BASE}/api/status`, { cache: 'no-store' });
      if (!response.ok) throw new Error('API недоступен');
      const data = await response.json();
      state.apiAvailable = true;
      state.apiConnected = !!data.connected;
      if (!state.apiCursorInitialized) {
        state.lastEventId = Number(data.last_event_id || 0);
        state.apiCursorInitialized = true;
      }
      setConnection(state.apiConnected, true);
    } catch {
      state.apiAvailable = false;
      setConnection(false, false);
    }
  }

  function setConnection(connected, apiAvailable) {
    connectionChip.classList.toggle('connected', connected);
    connectionChip.classList.toggle('error', apiAvailable && !connected);
    connectionLabel.textContent = connected ? 'TIKTOK LIVE ПОДКЛЮЧЁН' : apiAvailable ? 'ЧАТ НЕ ПОДКЛЮЧЁН' : 'ДЕМО-РЕЖИМ';
  }

  async function pollEvents() {
    if (!state.apiAvailable) return;
    try {
      const response = await fetch(`${API_BASE}/api/events?after=${state.lastEventId}`, { cache: 'no-store' });
      if (!response.ok) return;
      const data = await response.json();
      for (const event of data.events || []) {
        state.lastEventId = Math.max(state.lastEventId, Number(event.id || 0));
        if (event.type === 'join') addParticipant(event.name, event.unique_id || event.name, event.source || 'chat');
        if (event.type === 'manual_roster') setManualRoster(event.players || []);
        if (event.type === 'start') startManualRound();
        if (event.type === 'reset') resetGame();
      }
      if (data.connected !== undefined) {
        state.apiConnected = !!data.connected;
        setConnection(state.apiConnected, true);
      }
    } catch { /* keep the overlay alive during a short disconnect */ }
  }

  function setManualRoster(players) {
    resetGame();
    (players || []).slice(0, 30).forEach((item, index) => {
      const player = makePlayer(item.name, `manual_${index}_${item.name}`, 'manual', !!item.armored);
      player.color = PALETTE[index % PALETTE.length];
      player.lane = index % 6;
      state.players.push(player);
    });
    renderBoard(); renderPlanes();
    phaseTitle.textContent = state.players.length ? 'УЧАСТНИКИ ГОТОВЫ' : 'ЖДЁМ УЧАСТНИКОВ';
    phaseText.textContent = state.players.length ? 'Нажми «Запустить заезд» в панели управления' : 'Добавь ники в панели управления';
  }

  function startManualRound() {
    if (!state.players.length || state.phase === 'racing') return;
    state.phase = 'countdown';
    state.countdownAt = performance.now() + 3000;
    world.classList.remove('finished');
    phaseTitle.textContent = 'САМОЛЁТИКИ ГОТОВЫ';
    phaseText.textContent = 'Взлёт через несколько секунд…';
    waitingState.style.opacity = '1';
  }

  function resetGame() {
    state.phase = 'waiting'; state.players = []; state.queued = []; state.winner = null;
    state.countdownAt = 0; state.finishedAt = 0;
    winnerName.textContent = '?'; winnerMeta.textContent = 'ждём победителя';
    finishBanner.hidden = true; countdownEl.hidden = true;
    world.classList.remove('racing', 'finished');
    confettiLayer.innerHTML = '';
    layer.innerHTML = '';
    updateStatusText(); renderBoard(); updateMeter();
  }

  // Exposed only for local visual testing from the developer console.
  window.FlightGame = { addParticipant, reset: resetGame };

  async function init() {
    await apiStatus();
    setInterval(apiStatus, 4000);
    setInterval(pollEvents, 450);
    requestAnimationFrame(tick);
  }
  init();
})();
